mysqlx.UpdateStatement
======================

.. autoclass:: mysqlx.UpdateStatement
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
