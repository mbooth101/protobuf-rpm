mysqlx.Error
============

.. autoclass:: mysqlx.Error
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
