mysqlx.get_client
=================

.. autofunction:: mysqlx.get_client
