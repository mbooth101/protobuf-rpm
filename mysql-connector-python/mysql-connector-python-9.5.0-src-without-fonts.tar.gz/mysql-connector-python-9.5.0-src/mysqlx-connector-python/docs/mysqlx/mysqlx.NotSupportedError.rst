mysqlx.NotSupportedError
========================

.. autoclass:: mysqlx.NotSupportedError
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
