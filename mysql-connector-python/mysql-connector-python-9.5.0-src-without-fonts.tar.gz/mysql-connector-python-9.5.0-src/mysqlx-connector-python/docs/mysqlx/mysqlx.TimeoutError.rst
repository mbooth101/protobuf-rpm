mysqlx.TimeoutError
===================

.. autoclass:: mysqlx.TimeoutError
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
