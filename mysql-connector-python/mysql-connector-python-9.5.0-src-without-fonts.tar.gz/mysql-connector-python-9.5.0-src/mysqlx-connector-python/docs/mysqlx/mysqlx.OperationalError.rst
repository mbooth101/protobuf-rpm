mysqlx.OperationalError
=======================

.. autoclass:: mysqlx.OperationalError
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
