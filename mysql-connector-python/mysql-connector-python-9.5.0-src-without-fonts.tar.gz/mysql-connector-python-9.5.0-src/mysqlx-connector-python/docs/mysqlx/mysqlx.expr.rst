mysqlx.expr
===========

.. autofunction:: mysqlx.expr
