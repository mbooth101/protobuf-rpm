mysqlx.CreateCollectionIndexStatement
=====================================

.. autoclass:: mysqlx.CreateCollectionIndexStatement
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
