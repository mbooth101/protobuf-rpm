mysqlx.AddStatement
===================

.. autoclass:: mysqlx.AddStatement
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
