mysqlx.Collection
=================

.. autoclass:: mysqlx.Collection
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
