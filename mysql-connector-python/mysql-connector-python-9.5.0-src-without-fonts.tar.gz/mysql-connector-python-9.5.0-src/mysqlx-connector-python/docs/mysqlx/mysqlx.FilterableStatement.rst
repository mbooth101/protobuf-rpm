mysqlx.FilterableStatement
==========================

.. autoclass:: mysqlx.FilterableStatement
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
