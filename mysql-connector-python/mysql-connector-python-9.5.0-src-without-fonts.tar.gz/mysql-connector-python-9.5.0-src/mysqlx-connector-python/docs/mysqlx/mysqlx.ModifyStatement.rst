mysqlx.ModifyStatement
======================

.. autoclass:: mysqlx.ModifyStatement
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
