mysqlx.DataError
================

.. autoclass:: mysqlx.DataError
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
