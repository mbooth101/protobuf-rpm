mysqlx.RowResult
================

.. autoclass:: mysqlx.RowResult
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
