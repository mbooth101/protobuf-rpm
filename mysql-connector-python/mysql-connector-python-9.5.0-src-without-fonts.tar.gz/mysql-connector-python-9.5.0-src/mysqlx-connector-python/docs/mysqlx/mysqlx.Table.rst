mysqlx.Table
============

.. autoclass:: mysqlx.Table
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
