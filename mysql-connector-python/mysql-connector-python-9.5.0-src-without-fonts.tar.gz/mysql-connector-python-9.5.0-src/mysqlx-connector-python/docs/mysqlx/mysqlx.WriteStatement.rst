mysqlx.WriteStatement
=====================

.. autoclass:: mysqlx.WriteStatement
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
