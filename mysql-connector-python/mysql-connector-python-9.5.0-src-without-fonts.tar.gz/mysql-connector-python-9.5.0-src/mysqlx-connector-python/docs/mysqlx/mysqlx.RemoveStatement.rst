mysqlx.RemoveStatement
======================

.. autoclass:: mysqlx.RemoveStatement
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
