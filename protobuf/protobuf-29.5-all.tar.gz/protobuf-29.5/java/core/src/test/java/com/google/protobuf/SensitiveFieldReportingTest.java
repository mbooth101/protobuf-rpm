package com.google.protobuf;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

@RunWith(JUnit4.class)
public final class SensitiveFieldReportingTest {
  @Test
  public void testStub() throws Exception {
    // Open source fails if no tests are present.
  }
}
